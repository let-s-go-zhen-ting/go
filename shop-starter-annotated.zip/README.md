# 超簡單購物網站（GitHub Pages + Firebase）— 離線付款/上傳匯款截圖 版

這個專案是最小可行版本（MVP）：
- 前端放 **GitHub Pages**（`docs/` 資料夾）
- 後端用 **Firebase**（Auth 匿名登入 + Firestore + Storage）
- 付款方式：**匯款 / 無卡存款 / 貨到付款**（上傳匯款截圖，人工審單）
- **不用任何雲端函式**，全部前端完成（測試/個人小店可）

---

## 0) 你需要準備
- 一個 GitHub 帳號
- 一個 Firebase 專案（console.firebase.google.com）

## 1) 在 Firebase 做三件事（一步一步來）
1. **建立專案** → 「Build」→ 開啟 **Authentication**
   - 在「Sign-in method」啟用 **Anonymous** 與 **Email/Password**
   - 新增一個管理員帳號（Email/Password），例如：`llzhx1212@gmail.com`
2. **Firestore Database**
   - 建立資料庫（Production 模式）
   - 貼上 `firestore.rules` 內的規則（在 Firebase 主控台 → Firestore → 規則）
     - 請把規則檔中的 `YOUR_ADMIN_EMAIL@example.com` 換成你的管理員 Email
3. **Storage**
   - 啟用 Storage
   - 貼上 `storage.rules` 內的規則（Firebase 主控台 → Storage → 規則）

> 注意：若你在 2025/10/01 後使用 Storage，Firebase 可能要求升級到 Blaze（綁卡）。不超過免費額度時通常仍為 $0。

## 2) 取得 Firebase 設定
- Firebase 主控台 → 專案設定 → 「一般」→ *你的應用*（Web）→ 取得 `apiKey`、`authDomain`、`projectId`、`storageBucket` 等
- 打開 `docs/assets/firebase.js`，把 `YOUR_...` 全部換成你自己的

## 3) 啟用 GitHub Pages
1. 把這個資料夾整個推上你的 GitHub Repo
2. 進到 GitHub Repo → Settings → Pages → **Source: Deploy from a branch**
3. Branch 選 `main`，資料夾選 `/docs`
4. 儲存後，等它生成網址 `https://你的帳號.github.io/你的Repo/`

## 4) 怎麼用
- 逛商店：開 `index.html`
- 結帳：在 `index.html` 加入商品 → 進 `checkout.html` 填資料並建立訂單
- 上傳匯款截圖：在 `order.html`（建立訂單後會帶你去）上傳圖片
- 審單（管理員）：`admin.html` 登入你剛設定的管理員帳號 → 「標記為已付款」或「退回」

## 5) 你可以改的地方
- `docs/index.html` 裡的 `sampleProducts`：先內建兩個假商品，改成你自己的
- `docs/checkout.html` → 表單欄位可加「匯款後五碼」等
- `docs/assets/ui.css`：顏色/字型/間距
- Firestore 結構很簡單，若要更多欄位，可在 `docs/scripts/*.js` 擴充

祝順利上線！
